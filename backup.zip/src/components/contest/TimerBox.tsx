import React, { useState, useEffect } from "react";
import { Clock } from "lucide-react";

interface TimerBoxProps {
  initialTime?: number;
}

export const TimerBox: React.FC<TimerBoxProps> = ({ initialTime = 1800 }) => {
  const [timeLeft, setTimeLeft] = useState(initialTime);
  
  useEffect(() => {
    if (timeLeft <= 0) return;
    const interval = setInterval(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearInterval(interval);
  }, [timeLeft]);
  
  const minutes = String(Math.floor(timeLeft / 60)).padStart(2, "0");
  const seconds = String(timeLeft % 60).padStart(2, "0");
  const timerClass = timeLeft < 600 ? "text-red-400" : "text-yellow-400";

  return (
    <div className="flex items-center space-x-3">
      <Clock size={18} className="text-theme-secondary-text" />
      <span className="text-sm text-theme-secondary-text">Time Left:</span>
      <span className={`text-lg font-mono ${timerClass}`}>
        {minutes}:{seconds}
      </span>
    </div>
  );
};
