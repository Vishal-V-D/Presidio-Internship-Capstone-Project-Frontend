// src/context/AuthContext.tsx
import {
  createContext,
  useState,
  useEffect,
  type ReactNode,
  useCallback,
} from "react";
import { useNavigate } from "react-router-dom";
import { contestService } from "../api/contestService";

interface LoginData {
  email: string;
  password: string;
}

interface RegisterData {
  email: string;
  username: string;
  role: "organizer" | "contestant";
  password: string;
}

interface User {
  id: string;
  email: string;
  username: string;
  role: "organizer" | "contestant";
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (data: LoginData) => Promise<void>;
  logout: () => Promise<void>;
  registerUser: (data: RegisterData) => Promise<void>;
}

export const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  // ✅ Load active user
  useEffect(() => {
    const loadUser = async () => {
      try {
        const res = await contestService.getMe();
        setUser(res.data.user);
        localStorage.setItem("user", JSON.stringify(res.data));
      } catch {
        setUser(null);
        localStorage.removeItem("user");
      } finally {
        setLoading(false);
      }
    };

    loadUser();
  }, []);

  /** ✅ REGISTER USER */
  const registerUser = useCallback(
    async (data: RegisterData) => {
      if (data.role === "organizer") {
        await contestService.registerOrganizer({
          username: data.username,
          email: data.email,
          password: data.password,
        });
      } else {
        await contestService.registerContestant({
          username: data.username,
          email: data.email,
          password: data.password,
        });
      }

      navigate("/login");
    },
    [navigate]
  );

  /** ✅ LOGIN */
  const login = useCallback(
    async (data: LoginData) => {
      const res = await contestService.login(data);
      const loggedUser: User = res.data.user;

      setUser(loggedUser);
      localStorage.setItem("user", JSON.stringify(loggedUser));

      if (loggedUser.role === "organizer") {
        navigate("/organizer");
      } else {
        navigate("/contestant");
      }
    },
    [navigate]
  );

  /** ✅ LOGOUT */
  const logout = useCallback(async () => {
    try {
      await contestService.logout();
    } catch {}

    setUser(null);
    localStorage.removeItem("user");
    navigate("/login");
  }, [navigate]);

  return (
    <AuthContext.Provider
      value={{ user, loading, registerUser, login, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
};
