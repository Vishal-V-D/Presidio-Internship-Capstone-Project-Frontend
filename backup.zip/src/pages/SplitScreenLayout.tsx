import React from "react";
import { FaLaptopCode, FaRocket } from "react-icons/fa"; // Added icons for flavor

interface SplitScreenLayoutProps {
  formSide: React.ReactNode;
  isLogin: boolean;
}

export const SplitScreenLayout: React.FC<SplitScreenLayoutProps> = ({ formSide, isLogin }) => {
  // Define classes for consistency, using theme colors
  const accentPanelClass =
    "bg-theme-accent text-white p-8 md:p-16 flex flex-col justify-center items-center shadow-2xl transition-all duration-700 ease-in-out";
  // The cyan-600 is replaced by a custom class using the theme's accent color
  const cyanPanelClass =
    "bg-[hsl(var(--color-accent))] text-white p-8 md:p-16 flex flex-col justify-center items-center shadow-2xl transition-all duration-700 ease-in-out";
    
  const whitePanelClass =
    "bg-theme-secondary text-theme-primary p-8 md:p-16 flex flex-col justify-center items-center transition-all duration-700 ease-in-out";

  const marketingContent = isLogin
    ? {
        title: "Welcome Back, Coder!",
        icon: <FaLaptopCode className="text-6xl mb-4" />,
        text: "Please sign in to access your dashboard, manage your problems, or jump into the next contest.",
        cta: "New here? Register now!",
      }
    : {
        title: "Launch Your Journey!",
        icon: <FaRocket className="text-6xl mb-4" />,
        text: "Join our community! Whether you're here to compete or to organize the next big event, we've got you covered.",
        cta: "Already registered? Sign in!",
      };

  const isFormOnLeft = isLogin;

  const marketingPanel = (
    <div
      className={`w-full md:w-1/2 hidden md:flex ${cyanPanelClass} ${
        isFormOnLeft ? "rounded-r-2xl" : "rounded-l-2xl"
      } relative overflow-hidden`}
    >
      <div className="relative z-10 w-full h-full flex flex-col justify-center items-center text-center">
        {marketingContent.icon}
        <h2 className="text-4xl md:text-5xl font-bold mb-4">{marketingContent.title}</h2>
        <p className="text-lg md:text-xl opacity-90 leading-relaxed max-w-sm">{marketingContent.text}</p>
        
        {/* Mobile-only CTA (hidden on desktop) - styled to fit the dark background */}
        <p className="mt-8 text-base font-medium opacity-80 underline hover:opacity-100 cursor-pointer">
          {marketingContent.cta}
        </p>
      </div>

      {/* Decorative SVG Pattern in Background - adjusted opacity for sleekness */}
      <div className="absolute top-0 left-0 w-full h-full opacity-15 pointer-events-none">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          {/* Subtle concentric circles */}
          <circle cx="50" cy="50" r="45" fill="none" stroke="white" strokeWidth="0.5" />
          <circle cx="50" cy="50" r="30" fill="none" stroke="white" strokeWidth="0.5" />
          {/* Wave pattern at the bottom */}
          <path
            fill="white"
            opacity="0.1"
            d="M0 100 C 25 80, 75 80, 100 100 L 100 100 L 0 100 Z"
          />
        </svg>
      </div>
    </div>
  );

  const formPanel = (
    <div
      className={`w-full md:w-1/2 ${whitePanelClass} ${
        isFormOnLeft ? "md:rounded-l-2xl" : "md:rounded-r-2xl"
      } rounded-2xl md:rounded-none max-w-none`}
    >
      {/* Mobile marketing content - hidden on desktop */}
      <div className="flex flex-col md:hidden mb-6 text-center text-theme-primary">
        <h2 className="text-3xl font-bold mb-2">{marketingContent.title}</h2>
        <p className="text-lg opacity-90 text-theme-secondary">{marketingContent.text}</p>
      </div>

      <div
        key={isLogin ? "login" : "register"}
        className="w-full transition-opacity duration-500 ease-in-out animate-fade-in-slide-up"
      >
        {formSide}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center bg-theme-primary p-4">
      <div className="flex flex-col md:flex-row max-w-7xl overflow-hidden rounded-2xl shadow-3xl">
        {isFormOnLeft ? (
          <>
            {formPanel}
            {marketingPanel}
          </>
        ) : (
          <>
            {marketingPanel}
            {formPanel}
          </>
        )}
      </div>
    </div>
  );
};