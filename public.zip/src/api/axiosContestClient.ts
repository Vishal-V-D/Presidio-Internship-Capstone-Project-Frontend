// src/api/axiosContestClient.ts

import axios from "axios";

const axiosContestClient = axios.create({
  // Use the correct local server base URL
  baseURL: "http://localhost:4000/api",
  headers: { "Content-Type": "application/json" },
  // CRITICAL for handling HTTP-only cookies
  withCredentials: true,
});

// --- Request Interceptor ---
axiosContestClient.interceptors.request.use(
  (config) => {
    // Note: The /api/ is already in the baseURL, so config.url will be the relative path
    console.log(`🚀 [ContestService] ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => Promise.reject(error)
);

// --- Response Interceptor ---
axiosContestClient.interceptors.response.use(
  (res) => {
    console.log(`✅ [ContestService] ${res.config.url}`, res.status);
    return res;
  },
  (err) => {
    console.log(`❌ [ContestService] ${err.config?.url}`, err.response?.status);
    return Promise.reject(err);
  }
);

export default axiosContestClient;