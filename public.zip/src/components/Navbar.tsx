// src/components/Navbar.tsx
import { Link, useLocation } from "react-router-dom";
import { useContext, useState, useRef, useEffect } from "react";

import { AuthContext } from "../context/AuthContext";
import { ThemeContext } from "../context/ThemeContext";

import {
  Sun,
  Moon,
  UserCircle,
  ListChecks,
  Notebook,
  Gauge,
  Coins,
  Settings,
  Palette,
  LogOut,
} from "lucide-react";

export default function Navbar() {
  const auth = useContext(AuthContext);
  const themeCtx = useContext(ThemeContext);

  if (!auth || !themeCtx) return null;

  const { user, logout } = auth;
  const { theme, toggleTheme } = themeCtx;

  const location = useLocation();
  const [open, setOpen] = useState(false);

  const dropdownRef = useRef<HTMLDivElement | null>(null);

  // Close dropdown outside click
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  // hide navbar on guest pages and landing page
  if (["/", "/login", "/register"].includes(location.pathname)) return null;

  // Contestant navbar items
  const contestantNav = [
    { label: "Explore", to: "/explore" },
    { label: "Problems", to: "/problems" },
   
    { label: "Discuss", to: "/discuss" },
  ];

  // Organizer items
  const organizerNav = [
    { label: "Dashboard", to: "/organizer" },
    { label: "Manage Contests", to: "/organizer/contests" },
    { label: "Contact", to: "/contact" },
  ];

  const navItems = user?.role.toLocaleLowerCase() === "contestant" ? contestantNav : organizerNav;

  return (
    <nav className="sticky top-0 z-50 bg-theme-secondary shadow-md text-theme-primary">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-center h-14">

          {/* LOGO */}
          <Link
            to="/"
            className="text-2xl font-bold text-cyan-600 hover:text-cyan-500 transition"
          >
            Quantum Judge
          </Link>

          {/* MID NAV */}
          {user && (
            <div className="hidden md:flex gap-6 text-sm">
              {navItems.map((item) => (
                <Link
                  key={item.label}
                  to={item.to}
                  className="hover:text-cyan-400 transition"
                >
                  {item.label}
                </Link>
              ))}
            </div>
          )}

          {/* Right section */}
          <div className="flex items-center gap-4">

            {/* THEME SWITCH */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full bg-cyan-100 dark:bg-gray-700 hover:bg-cyan-200 dark:hover:bg-gray-600 transition text-cyan-600 dark:text-gray-200"
            >
              {theme === "light" ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            {/* AUTH / AVATAR */}
            {!user ? (
              <div className="flex gap-3">
                <Link
                  to="/login"
                  className="px-3 py-2 rounded-md hover:bg-cyan-600 hover:text-white"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="px-3 py-2 rounded-md bg-cyan-600 text-white hover:bg-cyan-700"
                >
                  Register
                </Link>
              </div>
            ) : (
              <div className="relative" ref={dropdownRef}>
                <button
                  onClick={() => setOpen((o) => !o)}
                  className="rounded-full p-1.5 hover:bg-gray-700"
                >
                  <UserCircle size={28} />
                </button>

                {open && (
                  <div className="absolute right-0 mt-2 w-72 bg-theme-secondary border border-gray-600 dark:border-gray-800 rounded-xl shadow-xl p-4">
                    
                    {/* USER INFO */}
                    <div className="flex gap-3 items-center mb-4">
                      <UserCircle size={42} />
                      <div>
                        <p className="font-semibold text-base">{user.username}</p>
                        <p className="text-xs text-gray-400">{user.email}</p>
                      </div>
                    </div>

                    {/* BUTTON GRID */}
                    <div className="grid grid-cols-4 gap-3 mb-4">
                      <Link to="/lists" className="flex flex-col items-center text-sm hover:opacity-80">
                        <ListChecks size={22} />
                        <span>Lists</span>
                      </Link>

                      <Link to="/notes" className="flex flex-col items-center text-sm hover:opacity-80">
                        <Notebook size={22} />
                        <span>Notes</span>
                      </Link>

                      <Link to="/progress" className="flex flex-col items-center text-sm hover:opacity-80">
                        <Gauge size={22} />
                        <span>Progress</span>
                      </Link>

                      <Link to="/points" className="flex flex-col items-center text-sm hover:opacity-80">
                        <Coins size={22} />
                        <span>Points</span>
                      </Link>
                    </div>

                    {/* Options */}
                    <div className="space-y-2 text-sm">

                      {/* ✅ Profile */}
                      <Link
                        to="/profile"
                        className="flex gap-2 items-center hover:opacity-80"
                      >
                        <UserCircle size={18} /> Profile
                      </Link>

                      <Link
                        to="/settings"
                        className="flex gap-2 items-center hover:opacity-80"
                      >
                        <Settings size={18} /> Settings
                      </Link>

                      <button
                        onClick={toggleTheme}
                        className="flex gap-2 items-center hover:opacity-80"
                      >
                        <Palette size={18} /> Appearance
                      </button>

                      <button
                        onClick={logout}
                        className="flex gap-2 items-center text-red-400 hover:opacity-80"
                      >
                        <LogOut size={18} /> Sign Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

          </div>
        </div>
      </div>
    </nav>
  );
}
