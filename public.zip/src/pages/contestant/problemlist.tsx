import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { contestService, type ProblemData } from '../../api/contestService';
import { Search, ChevronLeft, ChevronRight, Code2, Clock } from 'lucide-react';

const FilterCard = ({ title, count, isActive, onClick, difficulty }: { title: string; count: number; isActive: boolean; onClick: () => void; difficulty: string }) => {
    const getColors = () => {
        switch(difficulty) {
            case 'EASY': return 'from-green-500/20 to-green-600/20 border-green-500/50 text-green-400 hover:border-green-400';
            case 'MEDIUM': return 'from-yellow-500/20 to-yellow-600/20 border-yellow-500/50 text-yellow-400 hover:border-yellow-400';
            case 'HARD': return 'from-red-500/20 to-red-600/20 border-red-500/50 text-red-400 hover:border-red-400';
            default: return 'from-blue-500/20 to-blue-600/20 border-blue-500/50 text-blue-400 hover:border-blue-400';
        }
    };
    
    return (
        <div 
            onClick={onClick}
            className={`relative p-6 rounded-xl bg-gradient-to-br ${getColors()} border-2 cursor-pointer transition-all hover:scale-105 ${
                isActive ? 'ring-2 ring-[hsl(var(--color-accent))] shadow-xl' : 'hover:shadow-lg'
            }`}
        >
            <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold">{title}</h3>
                <span className="text-3xl font-bold">{count}</span>
            </div>
            {isActive && (
                <div className="absolute top-2 right-2 w-2 h-2 bg-[hsl(var(--color-accent))] rounded-full animate-pulse"></div>
            )}
        </div>
    );
};


const QuestionListItem = ({ problem, index, onClick }: { problem: ProblemData; index: number; onClick: () => void }) => {
    const difficulty = problem.difficulty || 'MEDIUM';
    let difficultyColor = '';
    let difficultyBg = '';
    let difficultyText = '';
    
    switch(difficulty.toUpperCase()) {
        case 'EASY':
            difficultyColor = 'text-green-400';
            difficultyBg = 'bg-green-500/10 border-green-500/30';
            difficultyText = 'Easy';
            break;
        case 'MEDIUM':
            difficultyColor = 'text-yellow-400';
            difficultyBg = 'bg-yellow-500/10 border-yellow-500/30';
            difficultyText = 'Medium';
            break;
        case 'HARD':
            difficultyColor = 'text-red-400';
            difficultyBg = 'bg-red-500/10 border-red-500/30';
            difficultyText = 'Hard';
            break;
        default:
            difficultyColor = 'text-gray-400';
            difficultyBg = 'bg-gray-700/30 border-gray-600/30';
            difficultyText = 'Medium';
    }

    return (
        <div 
            onClick={onClick}
            className="group flex items-center gap-4 p-4 bg-theme-secondary border border-theme rounded-xl hover:border-[hsl(var(--color-accent))] hover:bg-theme-secondary/80 transition-all cursor-pointer mb-3"
        >
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-theme-primary text-theme-secondary font-semibold group-hover:bg-[hsl(var(--color-accent))]/10 group-hover:text-[hsl(var(--color-accent))] transition-all">
                {index + 1}
            </div>
            
            <div className="flex-1">
                <h3 className="text-theme-primary font-semibold text-lg group-hover:text-[hsl(var(--color-accent))] transition-colors flex items-center gap-2">
                    <Code2 size={18} className="text-theme-secondary group-hover:text-[hsl(var(--color-accent))] transition-colors" />
                    {problem.title}
                </h3>
            </div>
            
            <div className={`px-3 py-1.5 rounded-lg border ${difficultyBg} ${difficultyColor} text-sm font-medium`}>
                {difficultyText}
            </div>
            
            <div className="flex items-center gap-2 px-3 py-1.5 bg-theme-primary rounded-lg text-theme-secondary text-sm">
                <Clock size={14} />
                {problem.timeLimit || 2}s
            </div>
        </div>
    );
}

function App() {
    const navigate = useNavigate();
    const [problems, setProblems] = useState<ProblemData[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [difficultyFilter, setDifficultyFilter] = useState<string>('');
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage] = useState(10);

    useEffect(() => {
        const fetchProblems = async () => {
            try {
                setLoading(true);
                const response = await contestService.listProblems(undefined, 1, 100);
                console.log('📚 Problems fetched:', response.data);
                
                // Handle different response structures
                const problemsData = Array.isArray(response.data) 
                    ? response.data 
                    : response.data.problems || response.data.data || [];
                
                setProblems(problemsData);
            } catch (err: any) {
                console.error('Failed to fetch problems:', err);
                setError(err.response?.data?.message || 'Failed to load problems');
            } finally {
                setLoading(false);
            }
        };

        fetchProblems();
    }, []);

    const handleProblemClick = (problemId: string | undefined) => {
        if (problemId) {
            navigate(`/problems/${problemId}`);
        }
    };

    // Filter problems based on search and difficulty
    const filteredProblems = problems.filter(problem => {
        const matchesSearch = problem.title.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesDifficulty = !difficultyFilter || problem.difficulty?.toUpperCase() === difficultyFilter;
        return matchesSearch && matchesDifficulty;
    });

    // Pagination logic
    const totalPages = Math.ceil(filteredProblems.length / itemsPerPage);
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const currentProblems = filteredProblems.slice(startIndex, endIndex);

    // Reset to page 1 when filters change
    useEffect(() => {
        setCurrentPage(1);
    }, [searchQuery, difficultyFilter]);
    
    return (
        <div className="min-h-screen bg-theme-primary p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-4xl font-bold text-theme-primary mb-2">Problem Set</h1>
                    <p className="text-theme-secondary">Practice coding problems and sharpen your skills</p>
                </div>

                {/* Filter Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                    <FilterCard 
                        title="All Problems" 
                        count={problems.length}
                        difficulty="ALL"
                        isActive={difficultyFilter === ''}
                        onClick={() => setDifficultyFilter('')}
                    />
                    <FilterCard 
                        title="Easy" 
                        count={problems.filter(p => p.difficulty?.toUpperCase() === 'EASY').length}
                        difficulty="EASY"
                        isActive={difficultyFilter === 'EASY'}
                        onClick={() => setDifficultyFilter('EASY')}
                    />
                    <FilterCard 
                        title="Medium" 
                        count={problems.filter(p => p.difficulty?.toUpperCase() === 'MEDIUM').length}
                        difficulty="MEDIUM"
                        isActive={difficultyFilter === 'MEDIUM'}
                        onClick={() => setDifficultyFilter('MEDIUM')}
                    />
                    <FilterCard 
                        title="Hard" 
                        count={problems.filter(p => p.difficulty?.toUpperCase() === 'HARD').length}
                        difficulty="HARD"
                        isActive={difficultyFilter === 'HARD'}
                        onClick={() => setDifficultyFilter('HARD')}
                    />
                </div>

                {/* Search Bar */}
                <div className="bg-theme-secondary border border-theme rounded-xl p-4 mb-6">
                    <div className="flex items-center gap-4">
                        <div className="relative flex-1">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-theme-secondary" size={20} />
                            <input 
                                type="text" 
                                placeholder="Search problems by title..." 
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="w-full bg-theme-primary border border-theme rounded-lg py-3 pl-11 pr-4 text-theme-primary placeholder-theme-secondary focus:outline-none focus:ring-2 focus:ring-[hsl(var(--color-accent))] focus:border-transparent transition-all"
                            />
                        </div>
                        
                        <div className="flex items-center gap-2 text-theme-secondary">
                            <span className="font-semibold text-[hsl(var(--color-accent))]">{filteredProblems.length}</span>
                            <span>/</span>
                            <span>{problems.length}</span>
                        </div>
                        
                        {(searchQuery || difficultyFilter) && (
                            <button 
                                onClick={() => { setSearchQuery(''); setDifficultyFilter(''); }}
                                className="px-4 py-2 bg-theme-primary hover:bg-[hsl(var(--color-accent))]/10 text-theme-secondary hover:text-[hsl(var(--color-accent))] rounded-lg transition-all font-medium"
                            >
                                Clear
                            </button>
                        )}
                    </div>
                </div>

                {/* Problem List */}
                <div>
                    {loading ? (
                        <div className="text-center py-20">
                            <div className="w-16 h-16 border-4 border-[hsl(var(--color-accent))] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                            <p className="text-theme-secondary text-lg">Loading problems...</p>
                        </div>
                    ) : error ? (
                        <div className="text-center py-20 bg-theme-secondary border border-theme rounded-xl">
                            <p className="text-[hsl(var(--color-error))] mb-4 text-lg">{error}</p>
                            <button 
                                onClick={() => window.location.reload()}
                                className="px-6 py-3 text-white rounded-lg transition-all font-semibold"
                                style={{ background: 'var(--button-theme-bg)' }}
                            >
                                Retry
                            </button>
                        </div>
                    ) : filteredProblems.length > 0 ? (
                        <>
                            <div className="space-y-0">
                                {currentProblems.map((problem, index) => (
                                    <QuestionListItem
                                        key={problem.id || index}
                                        problem={problem}
                                        index={startIndex + index}
                                        onClick={() => handleProblemClick(problem.id)}
                                    />
                                ))}
                            </div>

                            {/* Pagination */}
                            {totalPages > 1 && (
                                <div className="flex items-center justify-between mt-8 bg-theme-secondary border border-theme rounded-xl p-4">
                                    <div className="text-theme-secondary text-sm">
                                        Showing <span className="font-semibold text-theme-primary">{startIndex + 1}</span> to{' '}
                                        <span className="font-semibold text-theme-primary">{Math.min(endIndex, filteredProblems.length)}</span> of{' '}
                                        <span className="font-semibold text-theme-primary">{filteredProblems.length}</span> problems
                                    </div>
                                    
                                    <div className="flex items-center gap-2">
                                        <button
                                            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                                            disabled={currentPage === 1}
                                            className="flex items-center gap-2 px-4 py-2 bg-theme-primary hover:bg-[hsl(var(--color-accent))]/10 text-theme-secondary hover:text-[hsl(var(--color-accent))] rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                                        >
                                            <ChevronLeft size={18} />
                                            Previous
                                        </button>
                                        
                                        <div className="flex items-center gap-1">
                                            {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => {
                                                // Show first page, last page, current page, and pages around current
                                                if (
                                                    page === 1 ||
                                                    page === totalPages ||
                                                    (page >= currentPage - 1 && page <= currentPage + 1)
                                                ) {
                                                    return (
                                                        <button
                                                            key={page}
                                                            onClick={() => setCurrentPage(page)}
                                                            className={`w-10 h-10 rounded-lg font-medium transition-all ${
                                                                currentPage === page
                                                                    ? 'text-white'
                                                                    : 'bg-theme-primary text-theme-secondary hover:bg-[hsl(var(--color-accent))]/10 hover:text-[hsl(var(--color-accent))]'
                                                            }`}
                                                            style={currentPage === page ? { background: 'var(--button-theme-bg)' } : {}}
                                                        >
                                                            {page}
                                                        </button>
                                                    );
                                                } else if (page === currentPage - 2 || page === currentPage + 2) {
                                                    return <span key={page} className="text-theme-secondary px-1">...</span>;
                                                }
                                                return null;
                                            })}
                                        </div>
                                        
                                        <button
                                            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                                            disabled={currentPage === totalPages}
                                            className="flex items-center gap-2 px-4 py-2 bg-theme-primary hover:bg-[hsl(var(--color-accent))]/10 text-theme-secondary hover:text-[hsl(var(--color-accent))] rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                                        >
                                            Next
                                            <ChevronRight size={18} />
                                        </button>
                                    </div>
                                </div>
                            )}
                        </>
                    ) : (
                        <div className="text-center py-20 bg-theme-secondary border border-theme rounded-xl">
                            <Search size={48} className="mx-auto mb-4 text-theme-secondary" />
                            <p className="text-theme-primary text-lg">No problems found</p>
                            <p className="text-theme-secondary text-sm mt-2">Try adjusting your search or filters</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default App;