// src/pages/organizer/index.tsx

import React, { useContext } from "react";
import { Outlet, Link, useLocation } from "react-router-dom";
import { AuthContext } from "../../context/AuthContext";
import { Bell, User, LogOut } from "lucide-react";

// ✅ shadcn breadcrumb components
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "../../components/ui/breadcrumb";


// Custom labels for the main organizer routes
const customLabels: { [key: string]: string } = {
    // Updated: The index route ('/organizer') is now Dashboard
    '/organizer': 'Dashboard', 
    // New: Contest list page
    '/organizer/contests': 'Contests',
    // '/organizer/org-dashboard' is now removed/obsolete
    '/organizer/create': 'Create Contest',
    '/organizer/create-problem': 'Create Problem',
};

// Helper function to convert a URL slug (e.g., 'profile-settings') to a friendly label ('Profile Settings')
const slugToLabel = (slug: string) => {
  // Replace hyphens with spaces, then capitalize the first letter of each word
  return slug
    .replace(/-/g, " ") 
    .replace(/\b\w/g, (l) => l.toUpperCase());
};

// ✅ Generate breadcrumb path dynamically from URL
function useBreadcrumbs(pathname: string) {
  const segments = pathname.split("/").filter(Boolean);
  let curr = "";
  let breadcrumbs: { to: string; label: string }[] = [];

  segments.forEach((seg) => {
    curr += `/${seg}`;
    
    // Check for custom label first
    let label = customLabels[curr];
    
    if (!label) {
        // Fallback to dynamic slug conversion
        label = slugToLabel(seg);
    }

    breadcrumbs.push({
      to: curr,
      label: label,
    });
  });

  // Filter to only include organizer routes, starting from the base '/organizer'.
  const startIndex = breadcrumbs.findIndex(item => item.to === "/organizer");
  const filteredBreadcrumbs = startIndex >= 0 ? breadcrumbs.slice(startIndex) : [];
  
  return filteredBreadcrumbs;
}

// ✅ Custom Breadcrumb Component with Modern Styling
const CustomBreadcrumb: React.FC = () => {
  const { pathname } = useLocation();
  const breadcrumbs = useBreadcrumbs(pathname);

  // If the path is invalid or the array is empty, we don't render
  if (breadcrumbs.length === 0) return null;

  return (
    // Updated container styling: NO padding, background, or shadow
    <div className="text-sm mb-6">
      <Breadcrumb>
        <BreadcrumbList>
          {breadcrumbs.map((crumb, index) => (
            <React.Fragment key={crumb.to}>
              <BreadcrumbItem>
                {index === breadcrumbs.length - 1 ? (
                  // Current page styling: big, BOLD, and using the modern color highlight (purple/red)
                  <BreadcrumbPage className="!text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-red-500 transition">
                    {crumb.label}
                  </BreadcrumbPage>
                ) : (
                  // Link styling: prominent and clear, using gray for less focus, NOT BOLD
                  <BreadcrumbLink asChild>
                    <Link to={crumb.to} className="text-gray-500 hover:text-purple-600 font-normal transition text-base">
                      {crumb.label}
                    </Link>
                  </BreadcrumbLink>
                )}
              </BreadcrumbItem>
              {index < breadcrumbs.length - 1 && <BreadcrumbSeparator className="text-gray-400 mx-2" />}
            </React.Fragment>
          ))}
        </BreadcrumbList>
      </Breadcrumb>
    </div>
  );
};


export default function OrganizerLayout() {
  const { user, logout } = useContext(AuthContext)!;
  const location = useLocation();

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="min-h-screen bg-theme-background">
      {/* ... (Header and Navigation are the same) ... */}
      
      <main className="container mx-auto p-4 md:p-8 pt-24">
        {/* Breadcrumbs are now prominently displayed at the top of the content area */}
        <CustomBreadcrumb />

        {/* ✅ Content Wrapper */}
        <div className="bg-theme-secondary  border-theme rounded-2xl  p-6 md:p-8">
          <Outlet />
        </div>
      </main>

      {/* ... (Footer is the same) ... */}
    </div>
  );
}