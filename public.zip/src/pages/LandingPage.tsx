// src/pages/LandingPage.tsx

import React, { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import {
  Code2,
  Trophy,
  Users,
  Zap,
  Target,
  Award,
  CheckCircle,
  ArrowRight,
  Sparkles,
  Brain,
  Rocket,
  Shield,
} from "lucide-react";
import Hyperspeed, { hyperspeedPresets } from "../components/Hyperspeed";

const heroHyperspeedOptions = {
  onSpeedUp: () => {},
  onSlowDown: () => {},
  distortion: "turbulentDistortion" as const,
  length: 400,
  roadWidth: 10,
  islandWidth: 2,
  lanesPerRoad: 4,
  fov: 90,
  fovSpeedUp: 150,
  speedUp: 2,
  carLightsFade: 0.4,
  totalSideLightSticks: 20,
  lightPairsPerRoadWay: 40,
  shoulderLinesWidthPercentage: 0.05,
  brokenLinesWidthPercentage: 0.1,
  brokenLinesLengthPercentage: 0.5,
  lightStickWidth: [0.12, 0.5],
  lightStickHeight: [1.3, 1.7],
  movingAwaySpeed: [60, 80],
  movingCloserSpeed: [-120, -160],
  carLightsLength: [400 * 0.03, 400 * 0.2],
  carLightsRadius: [0.05, 0.14],
  carWidthPercentage: [0.3, 0.5],
  carShiftX: [-0.8, 0.8],
  carFloorSeparation: [0, 5],
  colors: {
    roadColor: 0x080808,
    islandColor: 0x0a0a0a,
    background: 0x000000,
    shoulderLines: 0xffffff,
    brokenLines: 0xffffff,
    leftCars: [0xd856bf, 0x6750a2, 0xc247ac],
    rightCars: [0x03b3c3, 0x0e5ea5, 0x324555],
    sticks: 0x03b3c3,
  },
};

export default function LandingPage() {
  const auth = useContext(AuthContext);
  const navigate = useNavigate();

  // If user is already logged in, redirect to their dashboard
  React.useEffect(() => {
    if (auth?.user) {
      if (auth.user.role === "organizer") {
        navigate("/organizer");
      } else if (auth.user.role === "contestant") {
        navigate("/explore");
      }
    }
  }, [auth?.user, navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 dark:from-gray-900 dark:via-gray-800 dark:to-purple-900">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 -z-10 pointer-events-none">
          <Hyperspeed effectOptions={heroHyperspeedOptions} />
          <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-purple-900/40 to-black/70" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8 animate-fade-in-slide-up">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 dark:bg-purple-900/30 rounded-full text-purple-700 dark:text-purple-300 text-sm font-semibold">
                <Sparkles size={16} className="animate-pulse" />
                Welcome to QuantumJudge
              </div>

              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-gray-900 dark:text-white leading-tight">
                Master Coding
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600 dark:from-purple-400 dark:to-pink-400">
                  Compete & Excel
                </span>
              </h1>

              <p className="text-xl text-gray-600 dark:text-gray-300 leading-relaxed">
                Join thousands of developers in competitive programming contests. Practice, compete, and showcase your skills on our advanced coding platform.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/register"
                  className="group relative inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
                >
                  <Rocket size={20} className="group-hover:animate-bounce" />
                  Get Started Free
                  <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                </Link>

                <Link
                  to="/login"
                  className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-bold rounded-xl shadow-lg hover:shadow-xl border-2 border-gray-200 dark:border-gray-700 transform hover:scale-105 transition-all duration-300"
                >
                  Sign In
                  <ArrowRight size={20} />
                </Link>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-6 pt-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600 dark:text-purple-400">10K+</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Active Users</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-pink-600 dark:text-pink-400">500+</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Contests</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">1M+</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Submissions</div>
                </div>
              </div>
            </div>

            {/* Right Content - Hyperspeed Animation */}
            <div className="relative animate-fade-in-slide-up animation-delay-300">
              <div className="relative h-[420px] sm:h-[480px]">
                <div className="absolute inset-0 rounded-3xl overflow-hidden shadow-2xl border border-white/20 dark:border-white/10 bg-black/90">
                  <Hyperspeed effectOptions={hyperspeedPresets.two} />
                </div>
               
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Immersive Contest Preview Section */}
      <section className="py-20 bg-white/80 dark:bg-gray-900/80 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 animate-fade-in-slide-up">
              <h2 className="text-4xl font-bold text-gray-900 dark:text-white">
                See the Contest Experience in Action
              </h2>
              <p className="text-lg text-gray-600 dark:text-gray-300">
                Track live leaderboards, review detailed test breakdowns, and celebrate
                every accepted submission. Our immersive interface keeps you focused on the
                race to the top.
              </p>
              <div className="flex flex-wrap gap-4 text-sm text-gray-600 dark:text-gray-300">
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-200">
                  <CheckCircle size={16} /> Real-time Judge Feedback
                </span>
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-pink-100 text-pink-700 dark:bg-pink-900/40 dark:text-pink-200">
                  <Trophy size={16} /> Competitive Leaderboards
                </span>
              </div>
            </div>

            <div className="relative animate-fade-in-slide-up">
              <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-8 border border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                    <Code2 className="text-white" size={24} />
                  </div>
                  <div>
                    <div className="font-bold text-gray-900 dark:text-white">Live Contest</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">Ends in 2h 34m</div>
                  </div>
                </div>

                <div className="bg-gray-900 rounded-lg p-4 mb-4 font-mono text-sm">
                  <div className="text-green-400">def solve(arr, target):</div>
                  <div className="text-blue-400 ml-4">for i in range(len(arr)):</div>
                  <div className="text-yellow-400 ml-8">if arr[i] == target:</div>
                  <div className="text-pink-400 ml-12">return i</div>
                  <div className="text-gray-500 ml-4">return -1</div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                    <CheckCircle size={16} />
                    <span className="text-sm">Test Case 1: Passed</span>
                  </div>
                  <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                    <CheckCircle size={16} />
                    <span className="text-sm">Test Case 2: Passed</span>
                  </div>
                  <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                    <CheckCircle size={16} />
                    <span className="text-sm">Test Case 3: Passed</span>
                  </div>
                </div>

                <div className="absolute -top-4 -right-4 bg-yellow-400 text-yellow-900 px-4 py-2 rounded-full font-bold shadow-lg animate-bounce">
                  🏆 +100 pts
                </div>
                <div className="absolute -bottom-4 -left-4 bg-green-400 text-green-900 px-4 py-2 rounded-full font-bold shadow-lg animate-pulse">
                  ✅ Accepted
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-fade-in-slide-up">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Why Choose QuantumJudge?
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Everything you need to excel in competitive programming
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature Cards */}
            {[
              {
                icon: <Trophy className="text-yellow-500" size={32} />,
                title: "Competitive Contests",
                description: "Participate in regular coding contests and climb the leaderboard",
                color: "from-yellow-500 to-orange-500",
              },
              {
                icon: <Brain className="text-purple-500" size={32} />,
                title: "AI-Powered Feedback",
                description: "Get intelligent insights and suggestions to improve your code",
                color: "from-purple-500 to-pink-500",
              },
              {
                icon: <Zap className="text-blue-500" size={32} />,
                title: "Real-time Judging",
                description: "Instant feedback with our lightning-fast code execution engine",
                color: "from-blue-500 to-cyan-500",
              },
              {
                icon: <Users className="text-green-500" size={32} />,
                title: "Community Driven",
                description: "Learn from thousands of developers and share your knowledge",
                color: "from-green-500 to-emerald-500",
              },
              {
                icon: <Target className="text-red-500" size={32} />,
                title: "Skill Tracking",
                description: "Monitor your progress with detailed analytics and insights",
                color: "from-red-500 to-pink-500",
              },
              {
                icon: <Shield className="text-indigo-500" size={32} />,
                title: "Secure Platform",
                description: "Enterprise-grade security for your code and data",
                color: "from-indigo-500 to-purple-500",
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="group bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-800 rounded-2xl p-8 shadow-lg hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-300 animate-fade-in-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className={`w-16 h-16 bg-gradient-to-br ${feature.color} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-gray-900 dark:to-purple-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-fade-in-slide-up">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Get Started in 3 Simple Steps
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Begin your coding journey today
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: "01",
                icon: <Users size={40} />,
                title: "Create Account",
                description: "Sign up as a contestant or organizer in seconds",
              },
              {
                step: "02",
                icon: <Code2 size={40} />,
                title: "Choose Contest",
                description: "Browse and join contests that match your skill level",
              },
              {
                step: "03",
                icon: <Award size={40} />,
                title: "Start Competing",
                description: "Solve problems, submit code, and earn points",
              },
            ].map((item, index) => (
              <div
                key={index}
                className="relative bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-xl animate-fade-in-slide-up"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <div className="absolute -top-6 left-8 w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-lg">
                  {item.step}
                </div>
                <div className="mt-8 mb-6 text-purple-600 dark:text-purple-400">
                  {item.icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                  {item.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-pink-600 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/10"></div>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="animate-fade-in-slide-up">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Ready to Start Your Journey?
            </h2>
            <p className="text-xl text-purple-100 mb-8">
              Join our community of passionate developers and take your coding skills to the next level
            </p>
            <Link
              to="/register"
              className="inline-flex items-center gap-3 px-10 py-5 bg-white text-purple-600 font-bold text-lg rounded-xl shadow-2xl hover:shadow-3xl transform hover:scale-105 transition-all duration-300"
            >
              <Rocket size={24} />
              Create Free Account
              <ArrowRight size={24} />
            </Link>
            <p className="mt-6 text-purple-100 text-sm">
              Already have an account?{" "}
              <Link to="/login" className="underline font-semibold hover:text-white">
                Sign in here
              </Link>
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Code2 className="text-purple-500" size={32} />
                <span className="text-xl font-bold text-white">QuantumJudge</span>
              </div>
              <p className="text-sm text-gray-400">
                The ultimate platform for competitive programming and skill development.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Platform</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/contests" className="hover:text-purple-400">Contests</Link></li>
                <li><Link to="/problems" className="hover:text-purple-400">Problems</Link></li>
                <li><Link to="/leaderboard" className="hover:text-purple-400">Leaderboard</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/about" className="hover:text-purple-400">About Us</Link></li>
                <li><Link to="/contact" className="hover:text-purple-400">Contact</Link></li>
                <li><Link to="/careers" className="hover:text-purple-400">Careers</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/privacy" className="hover:text-purple-400">Privacy Policy</Link></li>
                <li><Link to="/terms" className="hover:text-purple-400">Terms of Service</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-500">
            © 2024 QuantumJudge. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Custom Animations */}
      <style>{`
        @keyframes blob {
          0%, 100% { transform: translate(0, 0) scale(1); }
          25% { transform: translate(20px, -50px) scale(1.1); }
          50% { transform: translate(-20px, 20px) scale(0.9); }
          75% { transform: translate(50px, 50px) scale(1.05); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
        .animation-delay-300 {
          animation-delay: 300ms;
        }
      `}</style>
    </div>
  );
}
