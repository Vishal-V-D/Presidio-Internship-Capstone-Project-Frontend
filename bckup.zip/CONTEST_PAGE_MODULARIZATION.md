# Contest Page Modularization Guide

## ✅ Completed Components

I've successfully modularized the contest page by breaking it into separate, reusable components. Here's the structure:

### 📁 Component Structure

```
frontend/src/components/contest/
├── TimerBox.tsx              ✅ Created
├── ResizableDivider.tsx      ✅ Created  
├── DescriptionPanel.tsx      ✅ Created
└── index.tsx                 ✅ Created (exports all components)
```

---

## 📦 Created Components

### 1. **TimerBox.tsx**
**Purpose**: Displays countdown timer with color-coded warnings

**Props**:
- `initialTime?: number` - Starting time in seconds (default: 1800)

**Features**:
- Auto-countdown with useEffect
- Color changes: yellow (>10min), red (<10min)
- Clean, minimal UI with Clock icon

**Usage**:
```tsx
import { TimerBox } from '../../components/contest';

<TimerBox initialTime={1800} />
```

---

### 2. **ResizableDivider.tsx**
**Purpose**: Draggable divider for resizing panels

**Props**:
- `onResize: (position: number) => void` - Callback with mouse position
- `direction?: "horizontal" | "vertical"` - Divider orientation

**Features**:
- Smooth drag interaction
- Visual feedback on hover/drag
- Supports both horizontal and vertical layouts

**Usage**:
```tsx
import { ResizableDivider } from '../../components/contest';

<ResizableDivider 
  onResize={(x) => setLeftWidth(x)} 
  direction="horizontal" 
/>
```

---

### 3. **DescriptionPanel.tsx**
**Purpose**: Displays problem description and submissions history

**Props**:
- `problem: ProblemData` - Problem object with all details
- `onFullscreen: () => void` - Callback for fullscreen toggle

**Features**:
- Tabbed interface (Description / Submissions)
- Auto-fetches submissions when tab is active
- Submission statistics with visual charts
- Test cases display with input/output
- Constraints and additional info sections

**Usage**:
```tsx
import { DescriptionPanel } from '../../components/contest';

<DescriptionPanel 
  problem={problemData} 
  onFullscreen={() => setIsFullscreen(true)} 
/>
```

---

### 4. **index.tsx**
**Purpose**: Central export file for all contest components

**Exports**:
- `TimerBox`
- `ResizableDivider`
- `DescriptionPanel`
- `ScrollbarStyles` - Custom CSS component for hiding scrollbars

**Usage**:
```tsx
// Import all at once
import { TimerBox, ResizableDivider, DescriptionPanel, ScrollbarStyles } from '../../components/contest';
```

---

## 🔧 How to Integrate into Main Contest Page

### Step 1: Update Imports
Replace the inline components in `contestPage.tsx` with imports:

```tsx
import React, { useState, useEffect, useCallback } from "react";
import { useParams } from "react-router-dom";
import { 
  TimerBox, 
  ResizableDivider, 
  DescriptionPanel, 
  ScrollbarStyles 
} from "../../components/contest";
import { contestService, type ProblemData } from "../../api/contestService";
// ... other imports
```

### Step 2: Remove Inline Component Definitions
Delete these sections from `contestPage.tsx`:
- `TimerBox` component (lines ~39-59)
- `ResizableDivider` component (lines ~62-110)
- `DescriptionPanel` component (lines ~112-350)
- `ScrollbarStyles` component (lines ~19-36)

### Step 3: Use Components Directly
The JSX remains the same since component names haven't changed:

```tsx
return (
  <div className="flex flex-col h-screen bg-theme-primary">
    <ScrollbarStyles />
    
    {/* Top Bar */}
    <div className="flex items-center justify-between px-6 py-3 bg-theme-secondary border-b border-theme">
      <TimerBox initialTime={1800} />
      {/* ... other top bar content */}
    </div>

    {/* Main Content */}
    <div className="flex flex-1 overflow-hidden">
      <DescriptionPanel 
        problem={problem} 
        onFullscreen={() => setDescFullscreen(true)} 
      />
      
      <ResizableDivider 
        onResize={handleHorizontalResize} 
        direction="horizontal" 
      />
      
      {/* Code Editor Panel */}
      {/* ... rest of your code */}
    </div>
  </div>
);
```

---

## 🎯 Benefits of This Modularization

### 1. **Maintainability**
- Each component in its own file
- Easier to locate and fix bugs
- Clear separation of concerns

### 2. **Reusability**
- Components can be used in other pages
- Consistent UI across the application
- Easy to create variations

### 3. **Testing**
- Each component can be tested independently
- Easier to write unit tests
- Better code coverage

### 4. **Collaboration**
- Multiple developers can work on different components
- Reduced merge conflicts
- Clear component boundaries

### 5. **Performance**
- Components can be lazy-loaded if needed
- Better code splitting
- Optimized re-renders

---

## 📝 Remaining Work

### Components Still in Main File (To Be Modularized):

1. **CodeEditorPanel** (~400 lines)
   - Monaco editor integration
   - Language selector
   - Run/Submit buttons
   - Test results display

2. **TestCasePanel** (~200 lines)
   - Test case input/output
   - Custom test case creation
   - Results display

3. **TopBar** (~100 lines)
   - Timer
   - Live indicator
   - Reset button
   - Settings

### Recommended Next Steps:

1. Create `CodeEditorPanel.tsx`
2. Create `TestCasePanel.tsx`
3. Create `TopBar.tsx`
4. Update main `contestPage.tsx` to use all modular components
5. Add prop-types or TypeScript interfaces for better type safety
6. Write unit tests for each component

---

## 🚀 Quick Start

To use the modularized components immediately:

```tsx
// In your contestPage.tsx
import { 
  TimerBox, 
  ResizableDivider, 
  DescriptionPanel, 
  ScrollbarStyles 
} from "../../components/contest";

// Then use them as before - no changes to JSX needed!
```

---

## 📊 File Size Comparison

| Component | Lines | Complexity |
|-----------|-------|------------|
| TimerBox | 30 | Low |
| ResizableDivider | 60 | Medium |
| DescriptionPanel | 210 | High |
| **Total Extracted** | **300** | - |
| **Remaining in Main** | **~800** | - |

**Progress**: ~27% modularized ✅

---

## 💡 Tips for Further Modularization

1. **Keep components focused**: Each component should do one thing well
2. **Use TypeScript**: Proper typing prevents bugs
3. **Document props**: Add JSDoc comments for better DX
4. **Handle edge cases**: Null checks, loading states, errors
5. **Make components configurable**: Use props for customization

---

## 🎨 Styling Consistency

All components use:
- Global CSS variables (`--color-accent`, `--color-theme-primary`, etc.)
- Tailwind utility classes
- Consistent spacing and sizing
- Theme-aware colors (dark/light mode ready)

---

## ✅ Summary

The contest page has been successfully modularized with 3 core components extracted:
- ✅ TimerBox
- ✅ ResizableDivider  
- ✅ DescriptionPanel

All components are:
- Fully typed with TypeScript
- Using global CSS theme variables
- Exported from a central index file
- Ready to use with minimal changes to the main file

**Next**: Continue modularizing CodeEditorPanel and TestCasePanel for complete separation! 🚀
