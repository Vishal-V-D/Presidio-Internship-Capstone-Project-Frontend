// src/pages/LandingPage.tsx

import React, { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import {
  Code2,
  Trophy,
  Users,
  Zap,
  Target,
  Award,
  CheckCircle,
  ArrowRight,
  Sparkles,
  Brain,
  Rocket,
  Shield,
  Gauge,
} from "lucide-react";
import Hyperspeed from "../components/Hyperspeed";

const heroHyperspeedOptions = {
  onSpeedUp: () => {},
  onSlowDown: () => {},
  distortion: "turbulentDistortion" as const,
  length: 400,
  roadWidth: 10,
  islandWidth: 2,
  lanesPerRoad: 4,
  fov: 90,
  fovSpeedUp: 150,
  speedUp: 2,
  carLightsFade: 0.4,
  totalSideLightSticks: 20,
  lightPairsPerRoadWay: 40,
  shoulderLinesWidthPercentage: 0.05,
  brokenLinesWidthPercentage: 0.1,
  brokenLinesLengthPercentage: 0.5,
  lightStickWidth: [0.12, 0.5],
  lightStickHeight: [1.3, 1.7],
  movingAwaySpeed: [60, 80],
  movingCloserSpeed: [-120, -160],
  carLightsLength: [400 * 0.03, 400 * 0.2],
  carLightsRadius: [0.05, 0.14],
  carWidthPercentage: [0.3, 0.5],
  carShiftX: [-0.8, 0.8],
  carFloorSeparation: [0, 5],
  colors: {
    roadColor: 0x0a0a0a,
    islandColor: 0x050505,
    background: 0x000000,
    shoulderLines: 0x007fff, // Electric Blue
    brokenLines: 0x00ff7f, // Neon Green
    leftCars: [0x007fff, 0x00bfff, 0x00ffff], // Blue spectrum
    rightCars: [0x00ff7f, 0x00ff00, 0x7fff00], // Green spectrum
    sticks: 0x00bfff, // Cyan
  },
};

export default function LandingPage() {
  const auth = useContext(AuthContext);
  const navigate = useNavigate();

  // If user is already logged in, redirect to their dashboard
  React.useEffect(() => {
    if (auth?.user) {
      if (auth.user.role === "organizer") {
        navigate("/organizer");
      } else if (auth.user.role === "contestant") {
        navigate("/explore");
      }
    }
  }, [auth?.user, navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 dark:from-gray-900 dark:via-gray-800 dark:to-purple-900">
      {/* Hero Section with HyperSpeed Background */}
      <section className="relative overflow-hidden h-screen">
        {/* HyperSpeed as Background */}
        <div className="absolute inset-0 z-0">
          <Hyperspeed effectOptions={heroHyperspeedOptions} />
          {/* Darker overlay with gradient */}
          <div className="absolute inset-0 bg-gradient-to-br from-black/75 via-purple-900/40 to-black/80 dark:from-black/65 dark:via-purple-900/30 dark:to-black/70" />
          {/* Neon glow effects - Purple and Blue */}
          <div className="absolute top-1/4 left-1/4 w-[650px] h-[650px] rounded-full blur-[160px] animate-pulse" style={{background: 'radial-gradient(circle, rgba(139, 92, 246, 0.35) 0%, transparent 65%)'}} />
          <div className="absolute bottom-1/4 right-1/4 w-[650px] h-[650px] rounded-full blur-[160px] animate-pulse" style={{background: 'radial-gradient(circle, rgba(59, 130, 246, 0.35) 0%, transparent 65%)', animationDelay: '1.5s'}} />
          {/* Center accent glow */}
          <div className="absolute top-1/2 left-1/2 w-[550px] h-[550px] -translate-x-1/2 -translate-y-1/2 rounded-full blur-[140px] opacity-25 animate-pulse" style={{background: 'radial-gradient(circle, rgba(168, 85, 247, 0.5) 0%, transparent 50%)', animationDuration: '4s', animationDelay: '0.5s'}} />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24 h-full flex items-center">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8 animate-fade-in-slide-up">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-50 dark:bg-purple-500/20 rounded-full text-purple-600 dark:text-purple-300 text-sm font-semibold shadow-lg shadow-purple-500/30 border border-purple-200 dark:border-purple-500/30">
                <Sparkles size={16} className="animate-pulse" />
                Welcome to QuantumJudge
              </div>

              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight drop-shadow-[0_0_30px_rgba(139,92,246,0.8)]">
                Master Coding
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-violet-400 to-blue-400 drop-shadow-[0_0_50px_rgba(168,85,247,1)] animate-pulse" style={{animationDuration: '3s'}}>
                  Compete & Excel
                </span>
              </h1>

              <p className="text-xl text-gray-200 leading-relaxed drop-shadow-md">
                Join thousands of developers in competitive programming contests. Practice, compete, and showcase your skills on our advanced coding platform.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                {!auth?.user && (
                  <>
                    <Link
                      to="/register"
                      className="group relative inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-purple-500 via-violet-500 to-blue-500 text-white font-bold rounded-xl shadow-lg shadow-purple-500/50 hover:shadow-2xl hover:shadow-blue-500/80 transform hover:scale-105 transition-all duration-300 border border-purple-400/20"
                    >
                      <Rocket size={20} className="group-hover:animate-bounce" />
                      Get Started Free
                      <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                    </Link>

                    <Link
                      to="/login"
                      className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-black/50 backdrop-blur-sm text-white font-bold rounded-xl shadow-lg hover:shadow-2xl border-2 border-purple-400/40 hover:border-blue-400/60 hover:bg-black/60 transform hover:scale-105 transition-all duration-300"
                    >
                      Sign In
                      <ArrowRight size={20} />
                    </Link>
                  </>
                )}
                {auth?.user && (
                  <Link
                    to="/explore"
                    className="group relative inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-purple-500 via-violet-500 to-blue-500 text-white font-bold rounded-xl shadow-lg shadow-purple-500/50 hover:shadow-2xl hover:shadow-blue-500/80 transform hover:scale-105 transition-all duration-300 border border-purple-400/20"
                  >
                    <Sparkles size={20} className="group-hover:animate-spin" />
                    Explore Contests
                    <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                  </Link>
                )}
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-6 pt-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-400 drop-shadow-[0_0_25px_rgba(168,85,247,1)] animate-pulse" style={{animationDuration: '2s'}}>10K+</div>
                  <div className="text-sm text-gray-300">Active Users</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-violet-400 drop-shadow-[0_0_25px_rgba(139,92,246,1)] animate-pulse" style={{animationDuration: '2.5s'}}>500+</div>
                  <div className="text-sm text-gray-300">Contests</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-400 drop-shadow-[0_0_25px_rgba(59,130,246,1)] animate-pulse" style={{animationDuration: '3s'}}>1M+</div>
                  <div className="text-sm text-gray-300">Submissions</div>
                </div>
              </div>
            </div>

            {/* Right Content - Feature Grid */}
            <div className="relative animate-fade-in-slide-up animation-delay-300">
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-white/10 backdrop-blur-sm border border-purple-300/30 rounded-2xl p-6 hover:bg-purple-500/20 transition-all hover:border-purple-400/50">
                  <Brain className="w-12 h-12 text-purple-300 mb-4" />
                  <h3 className="text-xl font-bold text-white mb-2">Smart Algorithms</h3>
                  <p className="text-gray-300 text-sm">Practice with curated problems and intelligent hints</p>
                </div>
                <div className="bg-white/10 backdrop-blur-sm border border-violet-300/30 rounded-2xl p-6 hover:bg-violet-500/20 transition-all hover:border-violet-400/50">
                  <Trophy className="w-12 h-12 text-violet-300 mb-4" />
                  <h3 className="text-xl font-bold text-white mb-2">Compete & Win</h3>
                  <p className="text-gray-300 text-sm">Join live contests and climb the leaderboard</p>
                </div>
                <div className="bg-white/10 backdrop-blur-sm border border-blue-300/30 rounded-2xl p-6 hover:bg-blue-500/20 transition-all hover:border-blue-400/50">
                  <Zap className="w-12 h-12 text-blue-300 mb-4" />
                  <h3 className="text-xl font-bold text-white mb-2">Real-time Results</h3>
                  <p className="text-gray-300 text-sm">Get instant feedback on your submissions</p>
                </div>
                <div className="bg-white/10 backdrop-blur-sm border border-indigo-300/30 rounded-2xl p-6 hover:bg-indigo-500/20 transition-all hover:border-indigo-400/50">
                  <Shield className="w-12 h-12 text-indigo-300 mb-4" />
                  <h3 className="text-xl font-bold text-white mb-2">Secure Platform</h3>
                  <p className="text-gray-300 text-sm">Fair judging with advanced security measures</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* For Contestants & Organizers Section */}
      <section className="py-20 bg-gradient-to-br from-purple-100 via-pink-50 to-purple-100 dark:from-gray-800 dark:via-purple-900/20 dark:to-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Built for <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">Everyone</span>
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">Whether you compete or organize, we've got you covered</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* For Contestants */}
            <div className="group relative bg-gradient-to-br from-white to-purple-50 dark:from-gray-700 dark:to-purple-900/30 rounded-3xl p-8 shadow-2xl hover:shadow-purple-500/20 transition-all duration-500 border-2 border-purple-200 dark:border-purple-500/30 hover:border-purple-500">
              <div className="absolute -top-4 -right-4 bg-gradient-to-br from-purple-500 to-pink-500 text-white px-6 py-2 rounded-full font-bold shadow-lg">
                <Users size={20} className="inline mr-2" />
                For Contestants
              </div>
              <div className="mt-8 space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl p-3 text-white flex-shrink-0">
                    <Trophy size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Compete & Grow</h3>
                    <p className="text-gray-600 dark:text-gray-300">Join live contests, solve challenging problems, and climb the global leaderboard</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl p-3 text-white flex-shrink-0">
                    <Brain size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">AI-Powered Practice</h3>
                    <p className="text-gray-600 dark:text-gray-300">Get personalized feedback and hints in practice mode to sharpen your skills</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl p-3 text-white flex-shrink-0">
                    <Target size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Track Progress</h3>
                    <p className="text-gray-600 dark:text-gray-300">Monitor your improvement with detailed analytics and performance metrics</p>
                  </div>
                </div>
              </div>
            </div>

            {/* For Organizers */}
            <div className="group relative bg-gradient-to-br from-white to-pink-50 dark:from-gray-700 dark:to-pink-900/30 rounded-3xl p-8 shadow-2xl hover:shadow-pink-500/20 transition-all duration-500 border-2 border-pink-200 dark:border-pink-500/30 hover:border-pink-500">
              <div className="absolute -top-4 -right-4 bg-gradient-to-br from-pink-500 to-purple-500 text-white px-6 py-2 rounded-full font-bold shadow-lg">
                <Award size={20} className="inline mr-2" />
                For Organizers
              </div>
              <div className="mt-8 space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-gradient-to-br from-pink-500 to-purple-500 rounded-xl p-3 text-white flex-shrink-0">
                    <Rocket size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Host Contests Effortlessly</h3>
                    <p className="text-gray-600 dark:text-gray-300">Create and manage coding contests with our intuitive platform in minutes</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-gradient-to-br from-yellow-500 to-orange-500 rounded-xl p-3 text-white flex-shrink-0">
                    <Gauge size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Real-time Monitoring</h3>
                    <p className="text-gray-600 dark:text-gray-300">Track submissions, view leaderboards, and analyze participant performance live</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl p-3 text-white flex-shrink-0">
                    <Shield size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Secure & Scalable</h3>
                    <p className="text-gray-600 dark:text-gray-300">Handle thousands of submissions with enterprise-grade infrastructure</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Immersive Contest Preview Section */}
      <section className="py-20 bg-white/80 dark:bg-gray-900/80 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 animate-fade-in-slide-up">
              <h2 className="text-4xl font-bold text-gray-900 dark:text-white">
                See the Contest Experience in Action
              </h2>
              <p className="text-lg text-gray-600 dark:text-gray-300">
                Track live leaderboards, review detailed test breakdowns, and celebrate
                every accepted submission. Our immersive interface keeps you focused on the
                race to the top.
              </p>
              <div className="flex flex-wrap gap-4 text-sm text-gray-600 dark:text-gray-300">
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-200">
                  <CheckCircle size={16} /> Real-time Judge Feedback
                </span>
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-pink-100 text-pink-700 dark:bg-pink-900/40 dark:text-pink-200">
                  <Trophy size={16} /> Competitive Leaderboards
                </span>
              </div>
            </div>

            <div className="relative animate-fade-in-slide-up">
              <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-8 border border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                    <Code2 className="text-white" size={24} />
                  </div>
                  <div>
                    <div className="font-bold text-gray-900 dark:text-white">Live Contest</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">Ends in 2h 34m</div>
                  </div>
                </div>

                <div className="bg-gray-900 rounded-lg p-4 mb-4 font-mono text-sm">
                  <div className="text-green-400">def solve(arr, target):</div>
                  <div className="text-blue-400 ml-4">for i in range(len(arr)):</div>
                  <div className="text-yellow-400 ml-8">if arr[i] == target:</div>
                  <div className="text-pink-400 ml-12">return i</div>
                  <div className="text-gray-500 ml-4">return -1</div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                    <CheckCircle size={16} />
                    <span className="text-sm">Test Case 1: Passed</span>
                  </div>
                  <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                    <CheckCircle size={16} />
                    <span className="text-sm">Test Case 2: Passed</span>
                  </div>
                  <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                    <CheckCircle size={16} />
                    <span className="text-sm">Test Case 3: Passed</span>
                  </div>
                </div>

                <div className="absolute -top-4 -right-4 bg-yellow-400 text-yellow-900 px-4 py-2 rounded-full font-bold shadow-lg animate-bounce">
                  🏆 +100 pts
                </div>
                <div className="absolute -bottom-4 -left-4 bg-green-400 text-green-900 px-4 py-2 rounded-full font-bold shadow-lg animate-pulse">
                  ✅ Accepted
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}

      {/* How It Works Section */}
      <section className="py-20 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-gray-900 dark:to-purple-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-fade-in-slide-up">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Get Started in 3 Simple Steps
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Begin your coding journey today
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: "01",
                icon: <Users size={40} />,
                title: "Create Account",
                description: "Sign up as a contestant or organizer in seconds",
              },
              {
                step: "02",
                icon: <Code2 size={40} />,
                title: "Choose Contest",
                description: "Browse and join contests that match your skill level",
              },
              {
                step: "03",
                icon: <Award size={40} />,
                title: "Start Competing",
                description: "Solve problems, submit code, and earn points",
              },
            ].map((item, index) => (
              <div
                key={index}
                className="relative bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-xl animate-fade-in-slide-up"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <div className="absolute -top-6 left-8 w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-lg">
                  {item.step}
                </div>
                <div className="mt-8 mb-6 text-purple-600 dark:text-purple-400">
                  {item.icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                  {item.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Code2 className="text-purple-500" size={32} />
                <span className="text-xl font-bold text-white">QuantumJudge</span>
              </div>
              <p className="text-sm text-gray-400">
                The ultimate platform for competitive programming and skill development.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Platform</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/contests" className="hover:text-purple-400">Contests</Link></li>
                <li><Link to="/problems" className="hover:text-purple-400">Problems</Link></li>
                <li><Link to="/leaderboard" className="hover:text-purple-400">Leaderboard</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/about" className="hover:text-purple-400">About Us</Link></li>
                <li><Link to="/contact" className="hover:text-purple-400">Contact</Link></li>
                <li><Link to="/careers" className="hover:text-purple-400">Careers</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/privacy" className="hover:text-purple-400">Privacy Policy</Link></li>
                <li><Link to="/terms" className="hover:text-purple-400">Terms of Service</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-500">
            © 2024 QuantumJudge. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Custom Animations */}
      <style>{`
        @keyframes blob {
          0%, 100% { transform: translate(0, 0) scale(1); }
          25% { transform: translate(20px, -50px) scale(1.1); }
          50% { transform: translate(-20px, 20px) scale(0.9); }
          75% { transform: translate(50px, 50px) scale(1.05); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
        .animation-delay-300 {
          animation-delay: 300ms;
        }
      `}</style>
    </div>
  );
}
