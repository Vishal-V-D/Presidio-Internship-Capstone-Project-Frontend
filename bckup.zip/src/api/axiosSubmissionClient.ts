// src/api/axiosSubmissionClient.ts
import axios from "axios";

const axiosSubmissionClient = axios.create({
  baseURL: "http://localhost:5000/api",
  withCredentials: true, // ✅ required for cookies
  headers: { "Content-Type": "application/json" },
});

// Request Interceptor (no token logic needed)
axiosSubmissionClient.interceptors.request.use(
  (config) => {
    console.log(`🚀 [SubmissionService] ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => Promise.reject(error)
);

axiosSubmissionClient.interceptors.response.use(
  (res) => {
    console.log(`✅ [SubmissionService] ${res.config.url}`, res.status);
    return res;
  },
  (err) => {
    console.error(`❌ [SubmissionService] ${err.config?.url}`, err.response?.status);
    return Promise.reject(err);
  }
);

export default axiosSubmissionClient;
